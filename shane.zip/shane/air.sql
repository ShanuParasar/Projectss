CREATE DATABASE  IF NOT EXISTS `br_system` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `br_system`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: br_system
-- ------------------------------------------------------
-- Server version	5.5.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_table`
--

DROP TABLE IF EXISTS `admin_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_table` (
  `admin_id` varchar(15) NOT NULL DEFAULT '',
  `pass` varchar(15) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `mobile` bigint(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_table`
--

LOCK TABLES `admin_table` WRITE;
/*!40000 ALTER TABLE `admin_table` DISABLE KEYS */;
INSERT INTO `admin_table` VALUES ('dky12','Dky12345','Dharmendra Kumar Yadav',9934887034,'kumardharam83@gmail.com'),('sha12','sha12','shanu parasar',8709934638,'shanuparashar019@gmail.com');
/*!40000 ALTER TABLE `admin_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bus_day_avil`
--

DROP TABLE IF EXISTS `bus_day_avil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus_day_avil` (
  `bus_id` int(11) NOT NULL DEFAULT '0',
  `day` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`bus_id`,`day`),
  CONSTRAINT `br8` FOREIGN KEY (`bus_id`) REFERENCES `bus_table` (`bus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_day_avil`
--

LOCK TABLES `bus_day_avil` WRITE;
/*!40000 ALTER TABLE `bus_day_avil` DISABLE KEYS */;
INSERT INTO `bus_day_avil` VALUES (50001,'fri'),(50001,'mon'),(50001,'sat'),(50001,'sun'),(50001,'thu'),(50001,'tue'),(50001,'wed'),(50002,'fri'),(50002,'mon'),(50002,'sat'),(50002,'sun'),(50002,'thu'),(50002,'tue'),(50002,'wed'),(50003,'fri'),(50003,'mon'),(50003,'sat'),(50003,'sun'),(50003,'thu'),(50003,'tue'),(50003,'wed'),(50004,'fri'),(50004,'mon'),(50004,'sat'),(50004,'sun'),(50004,'thu'),(50004,'tue'),(50004,'wed'),(50005,'fri'),(50005,'mon'),(50005,'sat'),(50005,'sun'),(50005,'thu'),(50005,'tue'),(50005,'wed'),(50006,'fri'),(50006,'mon'),(50006,'sat'),(50006,'sun'),(50006,'thu'),(50006,'tue'),(50006,'wed'),(50007,'fri'),(50007,'mon'),(50007,'sat'),(50007,'sun'),(50007,'thu'),(50007,'tue'),(50007,'wed');
/*!40000 ALTER TABLE `bus_day_avil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bus_status`
--

DROP TABLE IF EXISTS `bus_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus_status` (
  `bus_id` int(11) NOT NULL DEFAULT '0',
  `date` varchar(20) NOT NULL DEFAULT '',
  `seat_no` int(11) NOT NULL DEFAULT '0',
  `status` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`bus_id`,`date`,`seat_no`),
  CONSTRAINT `br11` FOREIGN KEY (`bus_id`) REFERENCES `bus_table` (`bus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_status`
--

LOCK TABLES `bus_status` WRITE;
/*!40000 ALTER TABLE `bus_status` DISABLE KEYS */;
INSERT INTO `bus_status` VALUES (50004,'04/21/2018',1,'available'),(50004,'04/21/2018',2,'available'),(50004,'04/21/2018',3,'available'),(50004,'04/21/2018',4,'available'),(50004,'04/21/2018',5,'available'),(50004,'04/21/2018',6,'available'),(50004,'04/21/2018',7,'available'),(50004,'04/21/2018',8,'available'),(50004,'04/21/2018',9,'available'),(50004,'04/21/2018',10,'available'),(50004,'04/21/2018',11,'available'),(50004,'04/21/2018',12,'available'),(50004,'04/21/2018',13,'available'),(50004,'04/21/2018',14,'available'),(50004,'04/21/2018',15,'available'),(50004,'04/21/2018',16,'available'),(50004,'04/21/2018',17,'available'),(50004,'04/21/2018',18,'available'),(50004,'04/21/2018',19,'available'),(50004,'04/21/2018',20,'available'),(50004,'04/21/2018',21,'booked'),(50004,'04/21/2018',22,'available'),(50004,'04/21/2018',23,'available'),(50004,'04/21/2018',24,'available'),(50004,'04/21/2018',25,'available'),(50004,'04/21/2018',26,'available'),(50004,'04/21/2018',27,'available'),(50004,'04/21/2018',28,'available'),(50004,'04/21/2018',29,'available'),(50004,'04/21/2018',30,'available'),(50004,'04/21/2018',31,'available'),(50004,'04/21/2018',32,'available'),(50004,'04/21/2018',33,'available'),(50004,'04/21/2018',34,'available'),(50004,'04/21/2018',35,'available'),(50004,'04/21/2018',36,'available'),(50004,'04/21/2018',37,'available'),(50004,'04/21/2018',38,'available'),(50004,'04/21/2018',39,'available'),(50004,'04/21/2018',40,'available'),(50004,'04/21/2018',41,'available'),(50004,'04/21/2018',42,'available'),(50004,'04/21/2018',43,'available'),(50004,'04/21/2018',44,'available'),(50004,'04/21/2018',45,'available');
/*!40000 ALTER TABLE `bus_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bus_table`
--

DROP TABLE IF EXISTS `bus_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus_table` (
  `bus_id` int(11) NOT NULL DEFAULT '0',
  `bus_name` varchar(30) DEFAULT NULL,
  `bus_type` varchar(15) DEFAULT NULL,
  `total_seat` int(11) DEFAULT NULL,
  `source_stop` varchar(15) DEFAULT NULL,
  `destination_stop` varchar(15) DEFAULT NULL,
  `bording_time` varchar(15) DEFAULT NULL,
  `drop_time` varchar(15) DEFAULT NULL,
  `fare` int(11) DEFAULT NULL,
  `state` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`bus_id`),
  KEY `br5` (`source_stop`),
  KEY `br6` (`destination_stop`),
  CONSTRAINT `br5` FOREIGN KEY (`source_stop`) REFERENCES `stoppage_table` (`stop_id`),
  CONSTRAINT `br6` FOREIGN KEY (`destination_stop`) REFERENCES `stoppage_table` (`stop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_table`
--

LOCK TABLES `bus_table` WRITE;
/*!40000 ALTER TABLE `bus_table` DISABLE KEYS */;
INSERT INTO `bus_table` VALUES (50001,'INDIGO','BUSINESS',45,'KOL','MUM','10:00AM','12:30PM',10000,'active'),(50002,'INDIGO','BUSINESS',45,'KOL','MUM','04:00PM','06:30PM',10000,'active'),(50003,'INDIGO','BUSINESS',45,'KOL','MUM','10:00PM','12:30PM',10000,'active'),(50004,'INDIGO','BUSINESS',45,'DBG','DEL','05:00AM','07:00AM',15000,'active'),(50005,'INDIGO','ECONOMIC',45,'DBG','DEL','05:00AM','07:00AM',5000,'active'),(50006,'INDIGO','ECONOMIC',45,'DEL','DBG','10:00AM','12:00AM',5000,'active'),(50007,'INDIGO','BUSINESS',45,'DBG','DEL','10:00AM','12:10PM',15000,'active');
/*!40000 ALTER TABLE `bus_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `user_id` varchar(15) DEFAULT NULL,
  `ticket_id` varchar(20) NOT NULL DEFAULT '',
  `feedback` varchar(130) DEFAULT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `br21` (`user_id`),
  CONSTRAINT `br21` FOREIGN KEY (`user_id`) REFERENCES `user_table` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES ('sha12','98704635294','GOOD');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stoppage_table`
--

DROP TABLE IF EXISTS `stoppage_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stoppage_table` (
  `stop_id` varchar(10) NOT NULL DEFAULT '',
  `stop_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`stop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stoppage_table`
--

LOCK TABLES `stoppage_table` WRITE;
/*!40000 ALTER TABLE `stoppage_table` DISABLE KEYS */;
INSERT INTO `stoppage_table` VALUES ('BLR','BENGALURU'),('DBG','DARBHANGA'),('DEL','DELHI'),('DGHR','DEOGHAR'),('DGR','DURGAPUR'),('DHN','DHANBAD'),('GRD','GIRIDIH'),('HYD','HYDERABAD'),('JAL','JALPIFJHG'),('KOL','KOLKATA'),('MUM','MUMBAI'),('RNC','RANCHI'),('RNH','RANCHI');
/*!40000 ALTER TABLE `stoppage_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_table`
--

DROP TABLE IF EXISTS `ticket_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_table` (
  `ticket_id` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(30) DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `bus_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `seat_no` varchar(10) NOT NULL DEFAULT '',
  `mob` bigint(20) DEFAULT NULL,
  `user_id` varchar(15) DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ticket_id`,`seat_no`),
  KEY `br16` (`user_id`),
  CONSTRAINT `br16` FOREIGN KEY (`user_id`) REFERENCES `user_table` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_table`
--

LOCK TABLES `ticket_table` WRITE;
/*!40000 ALTER TABLE `ticket_table` DISABLE KEYS */;
INSERT INTO `ticket_table` VALUES ('98256917773','shanu','22','male',50004,'2018-04-21','21',7845982569,'sha12','Confirm'),('98704635294','DHARMENDRA','22','male',50004,'2018-04-21','8',7001987046,'sha12','Canceled');
/*!40000 ALTER TABLE `ticket_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_table`
--

DROP TABLE IF EXISTS `user_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_table` (
  `user_id` varchar(15) NOT NULL DEFAULT '',
  `pass` varchar(15) DEFAULT NULL,
  `s_question` varchar(20) DEFAULT NULL,
  `s_answer` varchar(100) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `m_status` varchar(10) DEFAULT NULL,
  `dob` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile` bigint(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_table`
--

LOCK TABLES `user_table` WRITE;
/*!40000 ALTER TABLE `user_table` DISABLE KEYS */;
INSERT INTO `user_table` VALUES ('dky12','Dky12345','color','red','Dharmendra Kumar Yadav','male','UnMarried','1996-05-23','kumardharam83@gmail.com',8371928726,'Darbhanga bihar'),('sha12','sha12','school','s.j.a','shanu parasar','male','UnMarried','1997-01-14','shanuparashar019@gmail.com',8709934638,'deoghar');
/*!40000 ALTER TABLE `user_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-21 15:54:29
