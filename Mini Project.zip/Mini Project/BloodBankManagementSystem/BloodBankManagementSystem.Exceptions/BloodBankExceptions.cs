﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankManagementSystem.Exceptions
{
    public class BloodBankExceptions :ApplicationException
    {
        public BloodBankExceptions() : base()
        {


        }

        public BloodBankExceptions(string message) : base(message)
        {


        }
        public BloodBankExceptions(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
