﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using BloodBankManagementSystem.Exceptions;
using BloodBankManagementSystem.Entities;
using System.Windows.Forms;


namespace BloodBankManagementSystem.DataAcessLayer
{
    public class BloodBankDAL
    {
       
        static string constr = string.Empty;         //connection string set as empty
        SqlConnection con = null;                    //sql connection object set to null 
        SqlCommand cmd = null;                       //sql command object set to null
        //creating static constructor to initialize the "constr" variable from the app.configue file 
        static BloodBankDAL()
        {
            constr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        // constructor to set the connection object to the connection string 
        public BloodBankDAL()
        {
            con = new SqlConnection(constr);
        }
        //method to varifying username and password
        public bool IsLogin(string userName, string password)
        {
            bool result = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu_MiniProject.uspIsLogin";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserName", userName);
                cmd.Parameters.AddWithValue("@Password", password);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    result = true;
                }

        }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("Invalid data" + ex);
            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return result;


        }

        //method to add details in database table bloodbank
        public int AddBloodBankDetails(BloodBank bb)
        {
            int result = 0;
            try
            {

                cmd = new SqlCommand();
                cmd.CommandText = "Shanu_MiniProject.uspAddBloodBankDetails";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@BloodBankId", bb.BloodBankId);
                cmd.Parameters.AddWithValue("@BloodBankName", bb.BloodBankName);
                cmd.Parameters.AddWithValue("@ContactNumber", bb.ContactNumber);
                cmd.Parameters.AddWithValue("@Address", bb.Address);
                cmd.Parameters.AddWithValue("@City", bb.City);
                cmd.Parameters.AddWithValue("@UserId", bb.UserId);
                cmd.Parameters.AddWithValue("@Password", bb.Password);
               
                con.Open();
                result = cmd.ExecuteNonQuery();



            }
            catch(BloodBankExceptions ex)
            {
                MessageBox.Show("Invalid data!!" +ex);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return result;


        }
        //method for displaying blood bank details
        public DataTable Display()
        {
            DataTable dt = null;
            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Shanu_MiniProject.uspDisplay";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("invalid data" +ex);
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;


        }

    }
}
