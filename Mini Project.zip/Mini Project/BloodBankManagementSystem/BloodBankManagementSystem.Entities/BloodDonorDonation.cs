﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankManagementSystem.Entities
{
    class BloodDonorDonation
    {
        private int bloodDonationId;
        private int bloodDonorId;
        private DateTime bloodDonationDate;
        private decimal weight;
        private int hBCount;
        private int numberOfBottle;

        public int BloodDonationId { get => bloodDonationId; set => bloodDonationId = value; }
        public int BloodDonorId { get => bloodDonorId; set => bloodDonorId = value; }
        public DateTime BloodDonationDate { get => bloodDonationDate; set => bloodDonationDate = value; }
        public decimal Weight { get => weight; set => weight = value; }
        public int HBCount { get => hBCount; set => hBCount = value; }
        public int NumberOfBottle { get => numberOfBottle; set => numberOfBottle = value; }
    }
}
