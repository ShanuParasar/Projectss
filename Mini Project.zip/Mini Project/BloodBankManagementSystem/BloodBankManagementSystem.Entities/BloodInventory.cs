﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankManagementSystem.Entities
{
    class BloodInventory
    {
        private int bloodInventoryId;
        private string bloodGroup;
        private int numberOfBottles;
        private int bloodBankId;
        private DateTime expiryDate;

        public int BloodInventoryId { get => bloodInventoryId; set => bloodInventoryId = value; }
        public string BloodGroup { get => bloodGroup; set => bloodGroup = value; }
        public int NumberOfBottles { get => numberOfBottles; set => numberOfBottles = value; }
        public int BloodBankId { get => bloodBankId; set => bloodBankId = value; }
        public DateTime ExpiryDate { get => expiryDate; set => expiryDate = value; }
    }
}
