﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankManagementSystem.Entities
{
    public class BloodBank
    {
        private int _bloodBankId;
        private string _bloodBankName;
        private string _address;
        private string _city;
        private long _contactNumber;
        private string _userId;
        private string _password;

        public int BloodBankId { get => _bloodBankId; set => _bloodBankId = value; }
        public string BloodBankName { get => _bloodBankName; set => _bloodBankName = value; }
        public string Address { get => _address; set => _address = value; }
        public string City { get => _city; set => _city = value; }
        public long ContactNumber { get => _contactNumber; set => _contactNumber = value; }
        public string UserId { get => _userId; set => _userId = value; }
        public string Password { get => _password; set => _password = value; }
    }
}
