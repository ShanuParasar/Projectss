﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BloodBankManagementSystem.DataAcessLayer;
using BloodBankManagementSystem.Entities;
using BloodBankManagementSystem.Exceptions;
using System.Windows.Forms;
using System.Data;


namespace BloodBankManagementSystem.BussinessLogicLayer
{
    public class BloodBankBLL
    {
        //creating object of data Acess Layer globally
        BloodBankDAL bbd = new BloodBankDAL();
        //Method for varifying UserName and Password
        public bool IsLogin(string userName, string password) 
            
        {
            bool isTrue = false;
            try
            {



                BloodBankDAL bbd = new BloodBankDAL();
                isTrue = bbd.IsLogin(userName, password);



            }
            catch(BloodBankExceptions ex)

            {
                MessageBox.Show("Inavalid Data"+ex);
            }
            return isTrue;

        }

        //method for adding details of blood bank
        public int AddBloodBankDetails(BloodBank bb)
        {
            int result = 0;
            try
            {
               
                BloodBankDAL bbd = new BloodBankDAL();
                result = bbd.AddBloodBankDetails(bb);
            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("invalid data" + ex);
            }
            return result;

        }

        //method for displaying Blood bank details
        public DataTable Display()
        {
            DataTable dt = null;
            try
            {
                BloodBankDAL dal = new BloodBankDAL();
               dt= dal.Display();
            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("invalid data" + ex);
            }
            return dt;
        }

       
        }

    
    
    
}
