﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BloodBankManagementSystem.Entities;
using BloodBankManagementSystem.Exceptions;
using BloodBankManagementSystem.BussinessLogicLayer;
using System.Data;

namespace BloodBankManagementSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for BloodBankAdd_view.xaml
    /// </summary>
    public partial class BloodBankAdd_view : Window
    {
        public BloodBankAdd_view()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            BloodBank bb = new BloodBank
            {
                BloodBankId=int.Parse(txtBloodBankId.Text),
                BloodBankName=txtBloodBankName.Text,
                Address=txtAddress.Text,
                City=txtCity.Text,
                ContactNumber=long.Parse(txtContactNo.Text),
                UserId=txtUserName.Text,
                Password=txtPassword.Password




            };
            
            try
            {
                BloodBankBLL bbb = new BloodBankBLL();
                int affectedRows = bbb.AddBloodBankDetails(bb);
                if (affectedRows > 0)
                {
                    MessageBox.Show("affected rows are: " + affectedRows);
                }
                else
                    MessageBox.Show("you entered invalid data");


                DataTable dt = bbb.Display();
                if (dt != null)
                {
                    dgDisplay.ItemsSource = dt.DefaultView;
                }
                else
                {
                    MessageBox.Show("table is empty");
                }

            }
            catch(BloodBankExceptions ex)
            {
                MessageBox.Show("invalid data!!" +ex);
            }
            txtAddress.Clear();
            txtBloodBankId.Clear();
            txtBloodBankName.Clear();
            txtCity.Clear();
            txtContactNo.Clear();
            txtPassword.Clear();
            txtUserName.Clear();

        }
    }
}
