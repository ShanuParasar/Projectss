﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BloodBankManagementSystem.BussinessLogicLayer;
using BloodBankManagementSystem.Entities;
using BloodBankManagementSystem.Exceptions;

namespace BloodBankManagementSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Window
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string userName = txtUserName.Text;
                string password = txtPassword.Password;
                BloodBankBLL bbb = new BloodBankBLL();
                if (userName != null && password != null)
                {
                    bool isTrue = bbb.IsLogin(userName,password);
                    if (isTrue)
                    {

                        Display d = new Display();
                        d.Show();
                        this.Close();
                    }
                    else
                        MessageBox.Show("wrong username or password");

                }
                else
                    MessageBox.Show("please enter username and password");
            }
            catch (BloodBankExceptions ex)
            {
                MessageBox.Show("Enter Valid Data" + ex);
            }
        }
        
    }
}
